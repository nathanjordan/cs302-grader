#include <iostream>

int main() {
    char letters[] = {'X', 'B', 'Z', 'D', 'W', 'F', 'G', 'K'};
    for( int i = 0; i < 7 ; i++ ) {
        std::cout << letters[i] << std::endl;
    }
    return 0;
}
