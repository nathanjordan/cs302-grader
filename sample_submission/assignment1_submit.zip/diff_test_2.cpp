#include <iostream>

int main() {
    int numbers[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    for( int i = 0; i < 9 ; i++ ) {
        std::cout << numbers[i] << std::endl;
    }
    return 0;
}
